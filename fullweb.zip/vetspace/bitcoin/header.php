








<header class="cex-ui-header">
    
    <div class="cex-ui-header-content">
        
        <a href="/"  style="text-decoration:none;color:rgb(200,50,50);" class="cex-ui-icon cex-ui-icon-big cex-ui-header-main-logo">
            <div class="header-image">
                  
                    
            </div>
            <h2 style="text-indent:10px;"><strong>Vetspace Online</strong></h2>
       </a>
       
       <style>
           
           
           
.header-image{
    

    background-image: url('bit.jpeg');
    background-size:cover;
    height:43px;
    width:43px;
    border-radius:50%;
    display:inline-block;
    margin-left:28px;
    margin-bottom:8px;
}

       </style>
       
       <div class="cex-ui-col-lg-0 cex-ui-col"><div class="cex-ui-menu cex-ui-menu-mobile">
       
       
       <div class="cex-ui-hamburger"><div class="cex-ui-hamburger-title"><div class="cex-ui-hamburger-button"><div class="cex-ui-hamburger-button-bar1"></div><div class="cex-ui-hamburger-button-bar2"></div><div class="cex-ui-hamburger-button-bar3"></div></div></div></div></div></div><div class="cex-ui-col-0 cex-ui-col-lg cex-ui-col"><div class="cex-ui-menu cex-ui-menu-desktop"><div class="cex-ui-popup column-products">
           
           <div class="cex-ui-popup-title"><big>   </big>
       
       
       <span class="cex-ui-popup-toggle"><span class="cex-ui-icon cex-ui-icon-big cex-ui-popup-toggle-btn"></span></span></div><ul class="cex-ui-popup-list" style="display: none;"><div class="cex-ui-row cex-ui-popup-list-row"><div class="cex-ui-col-12 cex-ui-col-lg cex-ui-col cex-ui-popup-list-column"><p class="cex-ui-paragraph cex-ui-paragraph-m cex-ui-paragraph-left cex-ui-popup-list-column-title"><b>For Everyone</b></p><div class="cex-ui-menu-item cex-ui-menu-sub-item"><div class="cex-ui-row"><a href="/buysell" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link">Instant Buy</a></div><div class="cex-ui-row"><p class="cex-ui-paragraph cex-ui-paragraph-xxs cex-ui-paragraph-left cex-ui-menu-item-desc">Buy crypto with your credit or debit card in a few clicks.</p></div></div><div class="cex-ui-menu-item cex-ui-menu-sub-item"><div class="cex-ui-row"><a href="/mobile" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link">CEX.IO Mobile App</a></div><div class="cex-ui-row"><p class="cex-ui-paragraph cex-ui-paragraph-xxs cex-ui-paragraph-left cex-ui-menu-item-desc">Buy, sell, earn and exchange crypto anywhere and anytime.</p></div></div><div class="cex-ui-menu-item cex-ui-menu-sub-item"><div class="cex-ui-row"><a href="https://staking.cex.io/" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link">Staking</a></div><div class="cex-ui-row"><p class="cex-ui-paragraph cex-ui-paragraph-xxs cex-ui-paragraph-left cex-ui-menu-item-desc">Get monthly rewards for simply holding stake-able coins.</p></div></div><div class="cex-ui-menu-item cex-ui-menu-sub-item"><div class="cex-ui-row"><a href="https://loan.cex.io/" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link">Loan</a></div><div class="cex-ui-row"><p class="cex-ui-paragraph cex-ui-paragraph-xxs cex-ui-paragraph-left cex-ui-menu-item-desc">Get a crypto-backed loan.</p></div></div><div class="cex-ui-menu-item cex-ui-menu-sub-item"><div class="cex-ui-row"><a class="cex-ui-text cex-ui-text-small cex-ui-text-disabled cex-ui-menu-item-link" disabled="">Savings</a><span class="cex-ui-badge cex-ui-menu-item-badge">Coming soon</span></div><div class="cex-ui-row"></div></div></div><div class="cex-ui-col-12 cex-ui-col-lg cex-ui-col cex-ui-popup-list-column"><p class="cex-ui-paragraph cex-ui-paragraph-m cex-ui-paragraph-left cex-ui-popup-list-column-title"><b>For Traders</b></p><div class="cex-ui-menu-item cex-ui-menu-sub-item"><div class="cex-ui-row"><a href="https://cex.io/btc-usd" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link">SPOT Trading</a></div><div class="cex-ui-row"><p class="cex-ui-paragraph cex-ui-paragraph-xxs cex-ui-paragraph-left cex-ui-menu-item-desc">Place limit, market orders and more here.</p></div></div><div class="cex-ui-menu-item cex-ui-menu-sub-item"><div class="cex-ui-row"><a href="https://broker.cex.io/" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link">Margin Trading</a><span class="cex-ui-badge cex-ui-menu-item-badge">Beta</span></div><div class="cex-ui-row"><p class="cex-ui-paragraph cex-ui-paragraph-xxs cex-ui-paragraph-left cex-ui-menu-item-desc">Trade cryptocurrencies on margin with up to 100x leverage.</p></div></div></div><div class="cex-ui-col-12 cex-ui-col-lg cex-ui-col cex-ui-popup-list-column"><p class="cex-ui-paragraph cex-ui-paragraph-m cex-ui-paragraph-left cex-ui-popup-list-column-title"><b>For Businesses</b></p><div class="cex-ui-menu-item cex-ui-menu-sub-item"><div class="cex-ui-row"><a href="https://aggregator.cex.io/" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link">CEX.IO Aggregator</a></div><div class="cex-ui-row"><p class="cex-ui-paragraph cex-ui-paragraph-xxs cex-ui-paragraph-left cex-ui-menu-item-desc">Liquidity provider for professional traders and enterprise clients.</p></div></div>
       
       <div class="cex-ui-menu-item cex-ui-menu-sub-item"><div class="cex-ui-row"><a href="https://cexdirect.com/" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link">CEX Direct</a></div>
       
       <div class="cex-ui-row"><p class="cex-ui-paragraph cex-ui-paragraph-xxs cex-ui-paragraph-left cex-ui-menu-item-desc">Make your website earn for you.</p></div></div>
       </div></div></ul></div>
       
       <div class="cex-ui-popup">
           
           <ul class="cex-ui-popup-list" style="display: none;"><div class="cex-ui-menu-item cex-ui-menu-sub-item">
                    
                    <div class="cex-ui-row"></div></div><div class="cex-ui-menu-item cex-ui-menu-sub-item"><div class="cex-ui-row"><a href="/fee-schedule" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link">
                            
                            Fee Schedule</a>
                
                </div><div class="cex-ui-row"></div></div></ul></div><div class="cex-ui-popup"><a style="text-decoration:none;" href="/about"><div class="cex-ui-popup-title"><span>About</span><span class="cex-ui-popup-toggle"><span class="cex-ui-icon cex-ui-icon-big cex-ui-popup-toggle-btn">
                
                </span></span></div></a></div>
                
                <div class="cex-ui-menu-item">
                    
                    <div class="cex-ui-row">
                        
                        <a href="/contact" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link">Contact us</a></div><div class="cex-ui-row">
                    
                    
                </div>
                
                </div>


                <?php

                if (!$_SESSION['access']) {




                    echo '<div class="cex-ui-auth-block cex-ui-menu-auth">
                
                
              <a href="/login" style="text-decoration:none;">  <button class="cex-ui-button cex-ui-button-small cex-ui-button-secondary-outlined">Sign In</button></a>
                
                
                <a href="/create" style="text-decoration:none;">  <button style="background:rgb(200,50,50);"  class="cex-ui-button cex-ui-button-small cex-ui-button-primary-contained">Create Account</button></a>
                
                
                </div>';
                }




                ?>
                
                
                
                </div>
                
                </div>
                
                </div>
                
                
                
                </header>