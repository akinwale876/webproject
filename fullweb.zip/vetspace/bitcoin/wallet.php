<!DOCTYPE html>
<html><head>


<?php

include 'head.php';

require 'admin_init.php';


?>



<title>Wallet - Vetspace.online</title>
<meta charset="utf-8">
<meta name="format-detection" content="telephone=no">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="CEX.IO is a worldwide Bitcoin exchange that offers access to high liquidity order book for professional traders, and simplified Bitcoin buying and selling for beginners.">
<meta name="google-site-verification" content="wgvrnzeB9Q7Awc6UGb0eU6aqPLh_28P-LXhz2dVWX3Y">
<meta property="og:title" content="Bitcoin Crypto Exchange - CEX.IO">
<meta property="og:description" content="CEX.IO is a secure exchange, where you can buy Bitcoins with your Visa/MasterCard in any currency and withdraw funds instantly.">
<meta property="og:image" content="http://cex.io/img/favicon64.png">
<meta property="og:image:secure_url" content="http://cex.io/img/favicon64.png">
<link rel="canonical" href="https://cex.io/about">
<link rel="mask-icon" href="http://cex.io/img/cex-fav.svg" color="#00bdca">
<link rel="shortcut icon" href="http://vetspace.online/bitc.jpg" type="image/x-icon">
<link rel="apple-touch-icon" href="/img/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72×72" href="/img/apple-touch-icon-72x72-precomposed.png">
<link rel="apple-touch-icon" sizes="114×114" href="/img/apple-touch-icon-114x114-precomposed.png">
<link rel="android-touch-icon" href="/img/android-icon-144x144-precomposed.png">
<link rel="icon" href="/img/favicon32.png" sizes="32×32">
<link rel="icon" href="/img/favicon48.png" sizes="48×48">
<link rel="icon" href="/img/favicon64.png" sizes="64×64">
<script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-593TDDD"></script>




<script type="application/ld+json">
    {
      "@context" : "http://schema.org",
      "@type" : "Organization",
      "name" : "CEX.IO",
      "url" : "https://cex.io",
      "logo": "https://cex.io/img/cex.svg",
      "sameAs" : [
        "https://www.facebook.com/pages/CEXIO/420149274752615",
        "https://twitter.com/cex_io"
      ]
    }
    </script>
<link rel="stylesheet" href="https://static.cex.io/landings/css/About.css?v=1.1.25
">

<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-593TDDD');</script>

<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="indexSafe" src="/scripts/gtm/indexSafe.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="GtmControl" src="/scripts/gtm/build/GtmControl.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="GtmGermeticSafe" src="/scripts/gtm/GtmGermeticSafe.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="CexMsgBus" src="/scripts/CexMsgBus.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="underscore" src="/scripts/underscore.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="CexMsgBusTransport" src="/scripts/CexMsgBusTransport.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="jquery" src="/scripts/jquery-1.10.2.min.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="gtm/gtmUrlConfig" src="/scripts/gtm/gtmUrlConfig.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="ws" src="/scripts/ws.js"></script>





</head>
<body>

  <?php


  include 'header.php';


  ?>

     
<div class="container">
    
    
    
   <div class="leftsider">
    <div style="background:white;padding:5px;padding-top:7px;padding-bottom:10px;min-height:90px;">
        <br>

<h2>Wallet</h2>
     <br>
    </div>
    <ul class="ul-list-account">
        
        <li>
            <a href="#dashboard" class="tablinks" onclick="openTab(event,'dashboard')" id="defaltOpen"><i class="fas fa-chart-line"></i>
<span class="text-icon">Dashboard</span></a>
        </li>
        
        <li>
            <a href="#transfer" class="tablinks" onclick="openTab(event,'fund')"><i class="fas fa-exchange-alt"></i><span class="text-icon">Send Bitcoin</span></a>
        </li>
        
        <li>
            <a href="#History" class="tablinks" onclick="openTab(event,'transaction')"><i class="fas fa-history"></i><span class="text-icon">Transaction History</span></a>
        </li>
        
        <li>
            <a href="#statement" class="tablinks" onclick="openTab(event,'statement')"><i class="fas fa-book-open"></i><span class="text-icon">Notifications</span></a>
        </li>
        
        <li>
            <a href="#profile" class="tablinks" onclick="openTab(event,'profile')"><i class="fas fa-user"></i><span class="text-icon">My profile</span></a>
        </li>
        
        <li>
            <a href="#settings" class="tablinks" onclick="openTab(event,'settings')"><i class="fa fa-cog"></i><span class="text-icon">Account Settings</span></a>
        </li>
        
        <li>
            <a href="/contact" ><i class="far fa-address-card"></i><span class="text-icon">Contact us</span></a>
        </li>
        <li>
             <a href="logout.php"><i class="fas fa-sign-out-alt"></i><span class="text-icon">Logout</span></a>
        </li>
        
        
    </ul>
    
    
    
   </div>
   
   
   

   <div class="mainview">
       
  
    <span class="iconn" style="float:right;"> <i class="fa fa-envelope"></i></span>
    
      
       <div name="dashboard" class="tabcontents" id="dashboard">
               
           
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>Dashboard</h2>

<div class="acct-page">
    
    
    
     <center>  <h4>My profile</h4>
    
  <img src="<?php echo $pic;?>" style="border-radius:50%;height:90px;width:90px;">
    <br>
    <?php
    
    
    
    
    echo '<h5>' . $firstname . ' ' . $lastname . '</h5>';
    
    
    ?>
    </center>
    
    
</div>

<div class="acct-page">
    
    
    
    
      

    <center> <h4>Notification</h4>
   <br> <i class="fas fa-bell" style="font-size:27px;"></i> </center> 
    
    
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
        
    $datatrans = mysqli_fetch_array($queryvtrans);
    


       $to_name = $datatrans['to_name'];
       $amount = $datatrans['amount'];
       $title = $datatrans['title'];
       
echo '<p style="color:green;">'. $title . ' '. $amount . '</p>';
    }
    
    
    
    ?>
</div>

<div class="acct-page">
    
    
    <center> <h4>Send Bitcoin</h4> <a href="#transfer" class="tablinks" onclick="openTab(event,'fund')"><i class="fas fa-exchange-alt" style="font-size:33px;"></i><span class="text-icon">Send Bitcoin</span></a> </center> 
    
    
    
    
    
</div>









       </div>
           
           
       <div name="transfer" class="tabcontents" id="fund">
               
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>Send Bitcoin</h2>



<div class="acct-page" style"margin:0;padding:10px;position:relative;">
       <div style="background:rgb(30,40,30);padding:7px;">
           <b>Bitcoin</b>
</div>
    <br>
    
   <div style="display:inline-block;margin-left:40px;">
       
    <form action="/" method="post" onsubmit="return false;">
        
        
        <label>Type</label>
        
        <select id="">
            
              <option>Tax</option>
              <option>payment</option>

            
        </select>
        
        <input type="number" placeholder="Account Number" id="account" />
        
        <br>
         USD<input type="radio" name="currency" value="USD">
         EUR<input type="radio" name="currency" value="EUR">
         GPD<input type="radio" name="currency" value="GPD">
    
         <br>
         
        <input type="number" placeholder="amount" id="amount" />
        <br>
    
        
       
        <input type="submit" onclick="rr()" value="Send" id="butto" />
        
        
    </form>
    
    <div class="hide" style="background:white;padding:0;">
    
<p id="status"></p>
               


    </div>
    
</div>

<style>
    
   .input-container{
       
       margin:0;
   }
    
    
    .hide{
        display:none;
        position:absolute;
        width:200px;
      border-radius:0;
        background:white;
        right:-20px;
        top:-15px;
        
        z-index:1;

    }
    
    .hide::after{
        content:"";
        position:absolute;
        bottom:-19px;
        left:10px;
        border-style:solid;
        border-width:13px;
        border-color:white transparent transparent  transparent;

        

    }
    
</style>

    
    <script>
        
        
        
var account,amount;

// preparing variables 

function _(el){

return document.getElementById(el);


}




// ..beginning of form validation...

function rr(){



 amount = _('amount');
account = _('account');



if(account.value == ''){
    
    _('status').innerHTML = '<p style="font-size:10px;color:red;">Enter account number</p>';

}else{
    
if(amount.value == ''){
    
    _('status').innerHTML = '<p style="font-size:10px;color:red;">Enter amount</p>';

}else{

_('status').innerHTML = '<p style="font-size:10px;"><b style="color:red;font-size:14px;">Transaction Failed</b><span style="display:block;">please set up a payout account to complete transfer<span></p>';

}

    
}


}
        
    </script>
    
    
    
    
    <script>
    
    
    

setTimeout(function(){
    
    
    
    
    $('#butto').click(function(){
        
        
    $('.hide').slideDown(200)
    
    
    })
    
    
    
    
    
    
},2000)


</script>

 </div>
 
 
    
<div class="acct-page" style"margin:0;padding:10px;">
       <div style="background:rgb(30,40,30);padding:7px;">
           <b>Last transactions</b>
</div>
    
    
       
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
        
    $datatrans = mysqli_fetch_array($queryvtrans);
    


       $to_name = $datatrans['to_name'];
       $amount = $datatrans['amount'];
       $title = $datatrans['title'];
       
echo '<p style="color:white;">'. $title . ' '. $amount . '</p>';
    }
    
    
    
    ?>
    
    
    </div>

           
       </div>
           
           
           
       <div name="history" class="tabcontents" id="transaction">
               
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>Transaction History</h2>
           
    
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
        
    $datatrans = mysqli_fetch_array($queryvtrans);
    


       $to_name = $datatrans['to_name'];
       $amount = $datatrans['amount'];
       $title = $datatrans['title'];
       
echo '<p style="color:white;">'. $title . ' '. $amount . '</p>';
    }
    
    
    
    ?>

       </div>
           
                      
       <div name="statement" class="tabcontents" id="statement">
               

           <?php 
           
         include 'accountdetails.php';

           
?>
               <h2>Account Statement</h2>

           
<div class="acct-page" style"margin:0;padding:0px;">
    
    
    <h4>Lists</h4>
    
    <ul class="profile-list">
        
 None
        
    </ul>
 
 
    </div>
       </div>  
       
       
       <div name="settings" class="tabcontents" id="settings">
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               
               <h2>Account Settings</h2>
               
               
<div class="acct-page" style"margin:0;padding:10px;">
    
               <h3 style="margin:3px;">Update Your Personal Info</h3>
               

    <form action="" method="" >
        
        
        <input type="text" placeholder="First Name" id="firstName" />
        <input type="text" placeholder="Last Name" id="lastName" />
 <br>
        <input type="submit" value="Update" id="submit" />
        
        
    </form>
    
 
        
    </ul>
 
 
    </div>
    
<div class="acct-page" style"margin:0;padding:10px;">
    
               <h3 style="margin:3px;">Update Your Password</h3>
               

    <form action="" method="" >
        
        
 
        <input type="text" placeholder="Old password" id="Oldpassword" />
        <input type="text" placeholder="New password" id="Newpassword" />
        <input type="text" placeholder="Confirm New password" id="ConNewpassword" />
  
  <br>
    
        <input type="submit" value="Update" id="submit" />
        
        
    </form>

 
        
    </ul>
 
 
    </div>
    
           
       </div>
                   
       <div name="profile" class="tabcontents" id="profile">
               
           
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>My profile</h2>
           
  
  
  
  
<div class="acct-page">

    
     <center>  
    
    <h4>My profile Picture</h4>
  <img src="<?php echo $pic;?>" style="border-radius:50%;height:90px;width:90px;">
    <br>
    <?php
    
    
    
    
    echo '<h5>' . $firstname . ' ' . $lastname . '</h5>';
    
    
    ?>
    </center>
    
    </div>
    
<div class="acct-page" style"margin:0;padding:0px;">
    
    
     <div style="background:rgb(30,40,30);padding:7px;">
           <b>Personal Information</b>
</div>
    
    
    <ul class="profile-list">
        
        
    
 <li> First name: <?php echo $firstname;?></li>
 <li>Last Name: <?php echo $lastname;?></li>
 <li> Email: <?php echo $email;?></li>
    
 <li> Address: <?php echo $address;?></li>
 <li>State: <?php echo $state;?></li>
 <li> Country: <?php echo $country;?></li>
 
 
        
    </ul>
 
 
    </div>
    
<div class="acct-page" style"margin:0;padding:0px;">
    
     <div style="background:rgb(30,40,30);padding:7px;">
           <b>Account Information</b>
</div>
    
    
    <ul class="profile-list">
        
 <li>Account Number: <?php echo $account_number;?></li>
 <li>Account Name: <?php echo $account_name;?></li>
 
        
 <li>Account Type: <?php echo $account_type;?></li>

        
    </ul>
 
 
    </div>
    
    <style>
        
        
        .profile-list{
            
            list-style:none;
            padding:0;
            margin:0;
        }
        
        .profile-list li{
            
           background:#262b2d;
           margin:0;
           padding:4px;
           font-family:arial;
           font-size:12px;
           padding-top:6px;
           padding-bottom:6px;
           
           display:block;
        }
        .profile-list li:nth-child(even){
            
           background:rgb(10,20,10);
        }
        
        
    </style>
    
    
    


 
    
  

       </div>
           
                  
    
<p style="color:rgb(100,100,100);font-weight:400;">
    
    
   
<small style="font-size:9px;">

<script language="JavaScript">

document.write('&copy;' );
document.write(' <b><i>Online Escrow</i> ');
document.write(new Date().getFullYear());
document.write(' </b> Alright Reserved');

</script>

</small>
 
</p>
    
    
    
   </div>

</div>


<style>



    .container{
        
        min-height:500px;
        background:rgb(22,22,22);
        
    }
    
    .leftsider{
        float:left;
        width:180px;
        min-height:600px;
        background:rgb(200,50,50);
        
    }
    
    .mainview{
        color:rgb(90,90,90);
        margin:-6px 178px;
        width:1054px;
        padding:10px;
        padding-top:0;
        min-height:100%;

    }
    
    
    
    
    
    .ul-list-account{
        
    list-style:none; 
    margin:0;
        padding:0;
    }
    .ul-list-account li{
   margin:0;
   padding:0;
    }
    
    .ul-list-account li a{
   
   
       text-decoration:none;
       padding:8px;
       padding-top:12px;
       padding-bottom:12px;
       display:block;
       color:white;
       font-size:13px;
       
       
    }
    .ul-list-account li a:hover{
   
   
      background:rgb(22,22,22);
       
       
    }
    
  .ul-list-account li a.active {
  background-color:rgb(22,22,22);
}
    
    
    .text-icon{
        
        display:inline-block;
        margin-left:4px;
        text-indent:4px;
    }
    
    
    
    .tabcontents{
        
        
        display:none;
    }
    
    
    .tabcontents {
  animation: fadeEffect 1s; /* Fading effect takes 1 second */
}




.input-container{
    background:#262b2d;
    width:230px;
    height:90px;
    box-shadow:none;
    overflow:hidden;
    padding:9px;
    color:white;
    border-radius:3px 0px;
    position:relative;
    
}

.acct-page{
    background:#262b2d;
    width:330px;
    height:260px;
    display:inline-block;
    box-shadow:none;
    overflow:hidden;
    padding:9px;
    color:white;
    border-radius:3px 0px;
    position:relative;
    
}


input{
    
    
    padding:6px;
}

input:hover{
    
    box-shadow:none;
}


/* Go from zero to full opacity */
@keyframes fadeEffect {
  from {opacity: 0;}
  to {opacity: 1;}
}


.icon-left{
    
    position:absolute;left:23px;top:27px;
    
}


.icon-right{
    
    position:absolute;right:20px;top:20px;
    
}


#icon{
    
    font-size:36px;
    
}


@media screen and (max-width:980px){
    
    
    
  .mainview  .text-icon{
        
        display:inline-block;
        margin-left:4px;
        text-indent:4px;
        
        font-size:10px;
    }
    
    
.acct-page{
    
      width:95%;
    height:250px;
    display:block;
    
    margin-bottom:3px;
    
    
    
}
    
    
    .leftsider{
        float:none;
        width:98%;
        min-height:auto;
        background:rgb(50,50,90);
        
    }
    
    .mainview{
        color:rgb(90,90,90);
        margin:0;
        width:98%;
        padding:10px;
        padding-top:0;
        min-height:100%;

    }



.input-container{
    background:#262b2d;
    width:42%;
    height:60px;
    display:inline-block;
    
}



.icon-left{
    
    position:absolute;left:23px;top:27px;
    
}


.icon-right{
    
    position:absolute;right:20px;top:20px;
    
}

.icon-right b{
    
    font-size:11px;
    
}


#icon{
    
    font-size:16px;
    
}


  
  
  
  
  
    .ul-list-account{
        
    list-style:none; 
    margin:0;
        padding:0;
    }
    .ul-list-account li{
   margin:0;
   padding:0;
          display:inline-block;

   
    }
    
    .ul-list-account li a{
   
   
       text-decoration:none;
       padding:8px;
       padding-top:12px;
       padding-bottom:12px;
       display:inline-block;
       color:white;
       font-size:13px;
       
       
    }
    .ul-list-account li a:hover{
   
   
      background:rgb(22,22,22);
       
       
    }
    
  .ul-list-account li a.active {
  background-color:rgb(22,22,22);
}
      
    
}


</style>



<script>
    
    function openTab(evt, TabContent) {
  // Declare all variables
  var i, tabcontent, tablinks;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tabcontents");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tablinks" and remove the class "active"
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  
  document.getElementById(TabContent).style.display = "block";
  evt.currentTarget.className += " active";
}
    
    
    
    
</script>


<script>
document.getElementById("defaltOpen").click();
</script>



</body>

</html>