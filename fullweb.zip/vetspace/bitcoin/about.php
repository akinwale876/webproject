<html>

<head>
<title>About Us - Vetspace.online</title>
<meta charset="utf-8">
<meta name="format-detection" content="telephone=no">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="CEX.IO is a worldwide Bitcoin exchange that offers access to high liquidity order book for professional traders, and simplified Bitcoin buying and selling for beginners.">
<meta name="google-site-verification" content="wgvrnzeB9Q7Awc6UGb0eU6aqPLh_28P-LXhz2dVWX3Y">
<meta property="og:title" content="Bitcoin Crypto Exchange - CEX.IO">
<meta property="og:description" content="CEX.IO is a secure exchange, where you can buy Bitcoins with your Visa/MasterCard in any currency and withdraw funds instantly.">
<meta property="og:image" content="http://cex.io/img/favicon64.png">
<meta property="og:image:secure_url" content="http://cex.io/img/favicon64.png">
<link rel="canonical" href="https://cex.io/about">
<link rel="mask-icon" href="/img/cex-fav.svg" color="#00bdca">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="/img/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72×72" href="/img/apple-touch-icon-72x72-precomposed.png">
<link rel="apple-touch-icon" sizes="114×114" href="/img/apple-touch-icon-114x114-precomposed.png">
<link rel="android-touch-icon" href="/img/android-icon-144x144-precomposed.png">
<link rel="icon" href="/img/favicon32.png" sizes="32×32">
<link rel="icon" href="/img/favicon48.png" sizes="48×48">
<link rel="icon" href="/img/favicon64.png" sizes="64×64">
<script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-593TDDD"></script><script type="application/ld+json">
    {
      "@context" : "http://schema.org",
      "@type" : "Organization",
      "name" : "CEX.IO",
      "url" : "https://cex.io",
      "logo": "https://cex.io/img/cex.svg",
      "sameAs" : [
        "https://www.facebook.com/pages/CEXIO/420149274752615",
        "https://twitter.com/cex_io"
      ]
    }
    </script>
<link rel="stylesheet" href="https://static.cex.io/landings/css/About.css?v=1.1.25
">

<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-593TDDD');</script>

<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="indexSafe" src="/scripts/gtm/indexSafe.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="GtmControl" src="/scripts/gtm/build/GtmControl.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="GtmGermeticSafe" src="/scripts/gtm/GtmGermeticSafe.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="CexMsgBus" src="/scripts/CexMsgBus.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="underscore" src="/scripts/underscore.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="CexMsgBusTransport" src="/scripts/CexMsgBusTransport.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="jquery" src="/scripts/jquery-1.10.2.min.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="gtm/gtmUrlConfig" src="/scripts/gtm/gtmUrlConfig.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="ws" src="/scripts/ws.js"></script></head>


<body>
    

<?php


include 'header.php';


?>














<main><section class="section our-mission-section"><div class="section-content-wrapper">

  <h1 class="our-mission-title">

    <div class="our-mission-title-word">

      <div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block">Our</div>


    </div>

    <div class="our-mission-title-word"><div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block">mission</div></div><div class="our-mission-title-word"  style="color: rgb(200,50,50);"><div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block">is</div></div>

    <div class="our-mission-title-word" style="color: rgb(200,50,50);">
      <div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block;color: rgb(200,50,50);">to</div></div><div class="our-mission-title-word"><div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block;color: rgb(200,50,50);">provide</div></div><div class="our-mission-title-word" style="color: rgb(200,50,50);">

        <div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block;color: rgb(200,50,50);">a</div></div><div class="our-mission-title-word" style="color: rgb(200,50,50);"><div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block;color: rgb(200,50,50);">gateway</div></div><div class="our-mission-title-word"><div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block;color: rgb(200,50,50);">into</div></div><div class="our-mission-title-word"><div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block;color: rgb(200,50,50);">the</div></div><div class="our-mission-title-word"><div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block;color: rgb(200,50,50);">world</div></div><div class="our-mission-title-word"><div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block;color: rgb(200,50,50);">of</div></div><div class="our-mission-title-word"><div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block;color: rgb(200,50,50);">an</div></div><div class="our-mission-title-word"><div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block;color: rgb(200,50,50);">open</div></div><div class="our-mission-title-word"><div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block;color: rgb(200,50,50);">financial</div></div><div class="our-mission-title-word">

  <div class="animate animated fadeInUp" style="animation-duration:1s;display:inline-block;color: rgb(200,50,50);">system</div></div>

</h1>

  <div class="our-mission-body">

  <div class="left-column">

  <div class="animate animated fadeIn" style="animation-duration:1s"><div class="our-mission-media left-picture"><picture><source srcset="https://static.cex.io/landings/media/3x-our-mission-section-left-picture.png" media="(min-width: 1440px)"><source srcset="https://static.cex.io/landings/media/2x-our-mission-section-left-picture.png" media="(min-width: 768px)"><img srcset="https://static.cex.io/landings/media/1x-our-mission-section-left-picture.png" alt="…"></picture></div></div>

  <div class="animate animated" style="animation-duration:1s"><div class="our-mission-text">We are a regulated multi-functional cryptocurrency exchange established in 2013 and now serving over 3 million customers worldwide.</div></div></div><div class="right-column">

  <div class="animate animated fadeIn" style="animation-duration:1s"><div class="our-mission-media right-picture"><picture><source srcset="https://static.cex.io/landings/media/3x-our-mission-section-right-picture.png" media="(min-width: 1440px)"><source srcset="https://static.cex.io/landings/media/2x-our-mission-section-right-picture.png" media="(min-width: 768px)"><img srcset="https://static.cex.io/landings/media/1x-our-mission-section-right-picture.png" alt="…"></picture></div></div></div></div></div></section>


  <section class="cex-ui-section cex-ui-section-bg-white about-us">


  <div class="cex-ui-section-content"><div class="about-us-content">

    <h2 class="cex-ui-title cex-ui-title-xl cex-ui-title-center about-us-title">About us</h2>


    <div class="cex-ui-row about-us-wrapper"><div class="cex-ui-col-12 cex-ui-col-sm-6 cex-ui-col-md-3 cex-ui-col about-us-content-item"><h3 class="cex-ui-title cex-ui-title-xxl about-us-content-title">2013</h3><p class="cex-ui-paragraph cex-ui-paragraph-m about-us-content-text">Market Entry Year</p></div><div class="cex-ui-col-12 cex-ui-col-sm-6 cex-ui-col-md-3 cex-ui-col about-us-content-item"><h3 class="cex-ui-title cex-ui-title-xxl about-us-content-title">3M+</h3><p class="cex-ui-paragraph cex-ui-paragraph-m about-us-content-text"><span>Registered Users</span><span>On Trade Platform</span></p></div><div class="cex-ui-col-12 cex-ui-col-sm-6 cex-ui-col-md-3 cex-ui-col about-us-content-item"><h3 class="cex-ui-title cex-ui-title-xxl about-us-content-title">0%</h3><p class="cex-ui-paragraph cex-ui-paragraph-m about-us-content-text">Customers' Funds Lost</p></div><div class="cex-ui-col-12 cex-ui-col-sm-6 cex-ui-col-md-3 cex-ui-col about-us-content-item"><h3 class="cex-ui-title cex-ui-title-xxl about-us-content-title">99%</h3><p class="cex-ui-paragraph cex-ui-paragraph-m about-us-content-text"><span>Countries Supported</span><span>and 47 US States</span></p></div></div></div></div></section><section class="section services-section"><div class="section-content-wrapper"><div class="services-section-block"><div class="services-section-media"><picture><source srcset="https://static.cex.io/landings/media/3x-services-section-picture.png" media="(min-width: 1440px)"><source srcset="https://static.cex.io/landings/media/2x-services-section-picture.png" media="(min-width: 768px)"><img srcset="https://static.cex.io/landings/media/1x-services-section-picture.png" alt="…"></picture></div><div class="services-section-content"><p>Vetspace.online was one of the first platforms to make fiat-to-crypto transactions accessible by offering card payments and bank transfers to the clients. We place a great effort into developing and maintaining robust relationships with dozens of reputable banks across the key markets.</p><p></p><p>Currently, we provide a rich variety of trading tools for <a href="/btc-usd">Bitcoin</a>, <a href="/bch-usd">Bitcoin Cash</a>, <a href="/eth-usd">Ethereum</a>, <a href="/xrp-usd">Ripple</a>, <a href="/xlm-usd">Stellar</a>, <a href="/ltc-usd">Litecoin</a>, <a href="/trx-usd">Tron</a>, and <a href="/btc-usd ">other crypto assets</a>. You can trade these cryptocurrencies for <a href="/btc-usd">USD</a>, <a href="/btc-eur">EUR</a>, <a href="/btc-gbp">GBP</a>, and <a href="/btc-rub">RUB</a>.</p><p>We know that mobility matters, so we’ve enabled trading through a website, <a href="/mobile">iOS and Android</a> mobile apps, WebSocket, and REST <a href="/cex-api">API</a>.</p></div></div></div></section><section class="section info-section"><div class="section-content-wrapper"><div class="info-section-block"><div class="info-section-media"><picture><source srcset="https://static.cex.io/landings/media/3x-info-section-picture.png" media="(min-width: 1440px)"><source srcset="https://static.cex.io/landings/media/2x-info-section-picture.png" media="(min-width: 768px)"><img srcset="https://static.cex.io/landings/media/1x-info-section-picture.png" alt="…"></picture></div><div class="info-section-content"><p class="info-section-content--item">Vetspace.online is a team of over 250 professionals working in several offices around the world: in the <b>United Kingdom of Great Britain and Northern Ireland</b>, <b>United States of America</b>, <b>Ukraine</b>, <b>Cyprus</b>, and <b>Gibraltar</b>. Our geographical expansion to new markets is backed by our regulatory accomplishments and development of new services for specific audiences.</p><p class="info-section-content--item">Over the last few years, Vetspace.online has grown into a group of companies with licenses in multiple jurisdictions. Vetspace.online LTD has been registered as Money Services Businesses (MSB), administered by the Financial Crimes Enforcement Network (FinCEN), a bureau of the US Department of the Treasury.</p><p class="info-section-content--item">Vetspace.online Limited received a Distributed Ledger Technology (DLT) license issued by the Gibraltar Financial Services Commission (GFSC). Vetspace.online Corp. has obtained Money Transmitter Licenses (MTLs) in 27 US states, and keep on working on covering more.</p><p class="info-section-content--item">Vetspace.online LTD has applied for a Digital payment token service license with the Monetary Authority of Singapore.</p><p class="info-section-content--item">We continue to build new services and improve upon existing ones. Earning your trust is always on our mind. Throughout our company’s history, effective and trustworthy collaboration with regulators has always been a top priority. Our teams are constantly working to maintain our compliance with evolving regulatory requirements and financial industry standards.</p><p class="info-section-content--item">Vetspace.online is also a founding member of CryptoUK, an association aimed at building cooperation between the major cryptocurrency players and regulatory authorities in the UK, with the goal of developing an appropriate operating framework for cryptocurrency businesses.</p></div></div></div></section>


        <section class="section our-values-section"><div class="section-content-wrapper"><h1 class="section-title our-values-title">Our Values</h1><div class="our-values-section-blocks"><div class="text-block"><h4 class="text-block-title"><img src="https://static.cex.io/landings/media/partnership.svg" alt=""><span>Customer centricity</span></h4><p class="text-block-description">At Vetspace, we put our customers at the core of our business. We’re passionate about creating services that support customers with a great experience toward their goals. Do we seek to innovate? Certainly. And before all endeavors, we ask our team to start with three simple questions: Do I understand the customer’s needs? Am I minimizing customer efforts? How does this increase customer value? If they’re ready to answer, then we go ahead!</p></div><div class="text-block"><h4 class="text-block-title"><img src="https://static.cex.io/landings/media/team.svg" alt=""><span>Teamwork</span></h4><p class="text-block-description">By treating others with respect, listening, and hearing, supporting each other, we stick to basic principles of human relationships. We value teamwork over personal ambition as the only way to success. What are we doing? We’re building a great team that’s a pleasure to work with.</p></div><div class="text-block"><h4 class="text-block-title"><img src="https://static.cex.io/landings/media/accountability.svg" alt=""><span>Accountability</span></h4><p class="text-block-description">We believe that by inspiring our team and trusting them, we create opportunities for Vetspace.online. We prefer free mindsets instead of detailed instructions where we can avoid them. The only golden rule we set is to be accountable — for actions we take, behaviors we demonstrate, and decisions we make.</p></div><div class="text-block"><h4 class="text-block-title"><img src="https://static.cex.io/landings/media/develop.svg" alt=""><span>Focus on the result</span></h4><p class="text-block-description">Our individual and team achievements are meaningful when they’re aligned with our company’s goals. We’re inspired by the things we do and the people for whom we do them. And we’re passionate about creating the best possible outcomes for our customers.</p></div></div></div></section>



</main>














<?php


 include 'footer.php';


?>









</body>
</html>