<?php

require    'stripe/init.php';



if($_POST['amount']){
    
    
    echo $_POST['amount'];
    
}





?>