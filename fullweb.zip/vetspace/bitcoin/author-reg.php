<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">


	<title>Register With us - Vetspace Online Crypto</title>

<link rel="stylesheet" type="text/css" href="jnmainstyle.css">

  

<meta name="robot" content="noindex" />

</head>
<body  style="background-image: url('photo.jpg');background-color: #cccccc;background-position: center;
  background-repeat: no-repeat;
  background-size:cover;">



<center>
<div style="position:relative;margin-top:40px;background:white;width:300px;min-height:360px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;border-radius:0px 8px 0px 8px;">  

<div class="header-image" style="display:inline-block;">  

</div>
<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;">Vetspace Online</h1>
</a>  

    

                       <center><h5>Sign up now and get your wallet</h5></center>



    <center>

                                    <form name="form" action="/" method="get" onsubmit="return false">

<div class="input-container">
  
<input type="text"  id="firstname" placeholder="First Name">


</div>

<div class="input-container">
  


<input type="text" id="lastname" placeholder="Last Name">
</div>







<div class="input-container">
  
<input type="text"  id="email" placeholder="Email">

</div>




<div class="input-container">
  
<input type="password"  id="password" placeholder="Create a Password">
</div>




<div class="input-container">
  
<input type="password"  id="confirm" placeholder="Confirm Password">

</div>




<br>
<input type="submit"  name="submit" onclick="register()" id="butto" value="Submit!" >

</form>



                            <p>already have account <a href="/login">Login</a></p>

</center>

    
    <div class="hide">
    
<p id="status"></p>
               
<p style="display:none;" id="loaded"></p>
               
<progress id="progressbar" style="display:none;" value="" max="100"></progress>

    </div>
    
</div>

<style>
    
   .input-container{
       
       margin:0;
   }
    
    
    .hide{
        display:none;
        position:absolute;
        width:200px;
      border-radius:0 40px 40px 40px;
        background:white;
        right:-220px;
        top:80px;
        
        

    }
    
    .hide::after{
        content:"";
        position:absolute;
        top:-1px;
        left:-25px;
        border-style:solid;
        border-width:13px;
        border-color:transparent white transparent transparent;

        

    }
    
</style>





<style>
    
    

    
    
    
    
</style>

</center>




<script src="reg.js"></script>





<script>
    
    
    

setTimeout(function(){
    
    
    
    
    $('#butto').click(function(){
        
        
    $('.hide').slideDown(200)
    
    
    })
    
    
    
    
    
    
},2000)


</script>
</body>
</html>