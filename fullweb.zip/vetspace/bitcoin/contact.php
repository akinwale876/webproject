<!DOCtype
 html>
<html>

<head>
<title>Contact Us | CEX.IO</title>
<meta charset="utf-8">
<meta name="format-detection" content="telephone=no">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="CEX.IO is a worldwide Bitcoin exchange that offers access to high liquidity order book for professional traders, and simplified Bitcoin buying and selling for beginners.">
<meta name="google-site-verification" content="wgvrnzeB9Q7Awc6UGb0eU6aqPLh_28P-LXhz2dVWX3Y">
<meta property="og:title" content="Bitcoin Crypto Exchange - CEX.IO">
<meta property="og:description" content="CEX.IO is a secure exchange, where you can buy Bitcoins with your Visa/MasterCard in any currency and withdraw funds instantly.">
<meta property="og:image" content="http://cex.io/img/favicon64.png">
<meta property="og:image:secure_url" content="http://cex.io/img/favicon64.png">
<link rel="canonical" href="https://cex.io/contacts">
<link rel="mask-icon" href="/img/cex-fav.svg" color="#00bdca">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="/img/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72×72" href="/img/apple-touch-icon-72x72-precomposed.png">
<link rel="apple-touch-icon" sizes="114×114" href="/img/apple-touch-icon-114x114-precomposed.png">
<link rel="android-touch-icon" href="/img/android-icon-144x144-precomposed.png">
<link rel="icon" href="/img/favicon32.png" sizes="32×32">
<link rel="icon" href="/img/favicon48.png" sizes="48×48">
<link rel="icon" href="/img/favicon64.png" sizes="64×64">
<script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-593TDDD"></script><script type="application/ld+json">
    {
      "@context" : "http://schema.org",
      "@type" : "Organization",
      "name" : "CEX.IO",
      "url" : "https://cex.io",
      "logo": "https://cex.io/img/cex.svg",
      "sameAs" : [
        "https://www.facebook.com/pages/CEXIO/420149274752615",
        "https://twitter.com/cex_io"
      ]
    }
    </script>
<link rel="stylesheet" href="https://static.cex.io/landings/css/Contacts.css?v=1.1.25
">

<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-593TDDD');</script>

<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="indexSafe" src="/scripts/gtm/indexSafe.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="GtmControl" src="/scripts/gtm/build/GtmControl.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="GtmGermeticSafe" src="/scripts/gtm/GtmGermeticSafe.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="CexMsgBus" src="/scripts/CexMsgBus.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="underscore" src="/scripts/underscore.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="CexMsgBusTransport" src="/scripts/CexMsgBusTransport.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="jquery" src="/scripts/jquery-1.10.2.min.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="gtm/gtmUrlConfig" src="/scripts/gtm/gtmUrlConfig.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="ws" src="/scripts/ws.js"></script></head>


<body>

<?php

include "header.php";

?>


<main><section class="section section--bg-grey contacts-section"><div class="section-content-wrapper"><h1 class="section-title contacts-title">Contact Us</h1><div class="contacts-section-main"><div class="contacts-section-head-block"><div class="company-info"><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">Vetspace.online LTD</p><p class="company-info-custom-field-value"></p></div><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">Correspondence address:</p><p class="company-info-custom-field-value">33 St. James's Square, London, England, SW1Y 4JS, United Kingdom</p></div><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">Vetspace.online Ltd VAT:</p><p class="company-info-custom-field-value">GB 307261820</p></div><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">Company number:</p><p class="company-info-custom-field-value">08757996</p></div><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">Email for complaints:</p><a class="company-info-link" href="mailto:complaint@cex.io">complaint@vetspace.online</a></div><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">Email for business inquiries:</p><a class="company-info-link" href="mailto:web@cex.io">web@vetspace.online</a></div><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">Support phone number:</p><p class="company-info-custom-field-value">+44 121 728 2228</p><p class="company-info-custom-field-value">+44 203 909 6911</p></div><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">Email for account-related issues and cardholder correspondence:</p><a class="company-info-link" href="mailto:support@cex.io">support@vetspace.online</a></div></div><div class="contacts-media"><picture><source srcset="https://static.cex.io/landings/media/3x-contacts.png" media="(min-width: 1440px)"><source srcset="https://static.cex.io/landings/media/2x-contacts.png" media="(min-width: 768px)"><img srcset="https://static.cex.io/landings/media/1x-contacts.png" alt="…"></picture></div></div><div class="contacts-section-bottom-block"><div class="company-info"><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">vetspace.online Corp</p><p class="company-info-custom-field-value"></p></div><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">Correspondence address:</p><p class="company-info-custom-field-value">101 Hudson Street, 21st Floor, Jersey City, NJ 07302.</p></div><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">MSB registration number with FinCEN:</p><p class="company-info-custom-field-value">31000159574904</p></div><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">Support phone number:</p><p class="company-info-custom-field-value">+1 877 569 4441 (Toll-free)</p></div></div><div class="company-info"><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">vetspace.online Limited</p><p class="company-info-custom-field-value"></p></div><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">Correspondence address:</p><p class="company-info-custom-field-value">57/63 Line Wall Road, Gibraltar, GX11 1AA</p></div><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">Company number</p><p class="company-info-custom-field-value">116846</p></div><div class="company-info-custom-field-block"><p class="company-info-custom-field-label">License number</p><p class="company-info-custom-field-value">FSC1345B</p></div></div></div></div></div></section></main>


    
    

<h1>Contact Us</h1>

	<form action="contact_server.php"   method="post">

    
    <div class="input-container">
    	



<input type="text" id="name" name="name" placeholder="Your Name"/>

    </div>

    
    <div class="input-container">
    	

<input type="text" id="email" name="email" placeholder="Email"/>



    </div>

		<br>
    
    	

<textarea id="message" name="message" placeholder="Message......" style="width:90%;min-height: 190px;">
</textarea>
    


		<br>
    
    
    <div class="input-container">
    	


<input type="submit" onclick="sendM()"  value="Send..!">


    </div>



	


	</form>

<div id="xdd"></div>

<script>



var name = document.getElementById('name');



var email = document.getElementById('email');



var message = document.getElementById('message');



var xdd = document.getElementById('x');



   function sendM() {
  


xdd.innerHTML ="ss...";

var formdata = new FormData();


formdata.append('name',name.value);

formdata.append('email',email.value);

formdata.append('message',message.value);



if (window.XMLHttpRequest) {
    // code for modern browsers
   var aja = new XMLHttpRequest();
 } else {
    // code for old IE browsers
   var aja = new ActiveXObject("Microsoft.XMLHTTP");
}




aja.upload.addEventListener('progress', progressHandl, false);
aja.addEventListener('load', completeHandl, false);
aja.addEventListener('error', errorHandl, false);
aja.addEventListener('abort', abortHandl, false);
aja.open("POST", "contact_server.php");
aja.send(formdata);



   	}




function progressHandl(event){

   // _('loaded').innerHTML = "uploaded " + event.loaded + "bytes of " + event.total;

//var percent = (event.loaded / event.total) * 100;

//_('status').innerHTML = Math.round(percent) + "% upload... please wait";
x.innerHTML = event.target.responseText;


}

function completeHandl(event){

x.innerHTML = event.target.responseText;


}

function errorHandl(event){

x.innerHTML = "upload failed";



}

function abortHandle(event){

x.innerHTML = "upload aborted";



}
	








</script>



=



<?php

include "footer.php";

?>


</body>
</html>