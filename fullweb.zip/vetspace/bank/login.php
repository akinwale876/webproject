<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>login - Online escrow account</title>


<meta property="og:locale" content="en_US">
<?php

include "head.php";

?>



<meta name="robot" content="noindex" />

</head>




<body style="background-image: url('photo.jpg');background-color: #cccccc;background-position: center;
  background-repeat: no-repeat;
  background-size: cover; ">
    


    
<div style="margin-top:40px;">

 
    


<center>
    
<div style="margin-top:90px;background:white;width:300px;min-height:360px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;border-radius:0px 8px 0px 8px;">
    
    
    <center>
        
        

<a href="https://<?php echo $_SERVER['SERVER_NAME']?>">
    
    
    <div class="header-image" style="display:inline-block;">  

</div>
<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;">Escrow account</h1>
</a>  

      <h4>Login to your account</h4>
</center>
    <br>

    
        <form method="post" action="admin.php" name="form" id="sub">
            
                 <div>
                        <input type="email" name="email" id="email" placeholder="Enter Email" required>
                 </div>
            
                 <div>
                        <input type="password" placeholder="Enter Password" id="password" name="password">
                 </div>
            
                 <div>
                        <input type="submit" value="Login!"   name="submit">
                 </div>
            
            
        </form>
    <br>

    
      <div>not registered:<a href="/create" style="margin-left:3px;">Sign up</a></div>


    
</div>
</center>

<script>
    
    
    
    
    
$('#sub').submit(function(){

var email = $('#email').val();
var password = $('#password').val();


  if(email == '' || password == ''){
      
      alert('fill in your details')
  }
          
});

    
    
    
    
</script>

</div>


<?php

include "footer.php";

?>


</body>

</html>