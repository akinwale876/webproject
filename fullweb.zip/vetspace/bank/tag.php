<!DOCtype
 html>
 
 
 <?php
 
 
 
require "connection.php";

 
 require 'admin_init.php';
 
 
 



$url = $_GET['url'];


 
 ?>
 
 
 
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?php echo $_GET['url'] . '"s Posts';  ?> & Biography - NaijaRamz</title>
<meta name="discription"
content="" />


<?php

include "head.php";

?>


</head>


<body>
      
      <?php 
      
      include 'header.php';
      
      ?>
    
<div class="wrapper" >

<div class="main">
    
<center>
    <br>
    
    <?php 
    
    if($url == 'Wizkid' || $url == 'wizkid' || $url == 'wizkid'){
    
    
        echo '<h2>' . $url .' Biography</h2>';

    
            $post_query = mysqli_query($conn,"SELECT * FROM `posts` WHERE tag = '$url'  ORDER BY id DESC LIMIT 1");

$mo = mysqli_fetch_array($post_query);


$image = str_replace('http','https',$mo['picture_url']);


    
    
    echo '<img src="'.$image.'" height="190px" >';

    











echo '</center>';

        echo ' <h2>About <span style="color:rgb(100,100,100);">'. $url . '</span></h2>';
        
echo '<ul style="list-style:none;"> ';   
echo '<li><h4 style="display:inline-block;">Surname: </h4>  Not available yet</li>';
        
        
       echo ' <li><h4 style="display:inline-block;">date Of Birth:</h4> Not available yet</li>';
        
        
       echo ' <li><h4 style="display:inline-block;">Nationality:</h4> Not available yet</li>';
        
        
       echo ' <li><h4 style="display:inline-block;">Family background:</h4> Not available yet</li>';
        
        
        
   echo '</ul>';
         
        
        echo '<h2>Read about <span style="color:red;">'. $url .'</span> here</h2>';


echo '<p>' . $url . ' Short story</p>';







}

?>




<br/>
    
<br/>
    
    <h2><?php echo $_GET['url']; ?>'s post</h2>
    
    
<?php


            $list_post_query = mysqli_query($conn,"SELECT * FROM `posts` WHERE tag = '$url'  ORDER BY id DESC LIMIT 10");











while($mov = mysqli_fetch_array($list_post_query)){

$list_title = $mov['title'];
$list_cleanurl = $mov['cleanurl'];
$list_image = $mov['picture_url'];
$list_description = $mov['description'];
$list_content = $mov['description'];

$list_category = $mov['category'];
$list_comments = $mov['comments'];
$list_comments_id = $mov['comment_id'];
$list_views = $mov['views'];

$list_date = date(' l  d / M / Y',$mov['date']);

$current_date = date_create();

$current_date = date_timestamp_get($current_date);


$count_date = $mov['date'];



$count_date =  ($current_date - $count_date);

$comment_post_query = mysqli_query($conn,"SELECT * FROM `comment` WHERE `comment_id` = '$list_comments_id'");


$num_post_query = mysqli_num_rows($comment_post_query);







  
  $days = floor($count_date / (60 * 60 * 24));
  $hours = floor(($count_date % (60 * 24)) / (1000 * 60 * 60));
 $minutes = floor(($count_date % ( 60)) / (1000 * 60));
 $seconds = floor(($count_date % (1000 * 60)) / 1000);
  
  



    $time = $minutes  . ' mins ';
    
$likes = $mov['likes'];

echo '<a style="text-decoration:none;color:black;" href="http://'. $_SERVER["SERVER_NAME"].'/'.$url.'/'.$list_cleanurl.'">

<div class="post" style="position:relative;">


<img alt="'.$list_title.'" class="img" src="'. str_replace('http',  'https', $list_image).'">


<div class="post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($list_title).'</h4>

<span class="hov" style="padding:3px;font-size:9px;>'.$list_category.'</span>


<b style="color:rgb(10,10,100);position:absolute;left:9px;bottom:10px;"><small><i class="fa fa-clock">'. $list_date .'</i>
</small><span style="margin-left:5px;color:red;font-size:10px;"><i class="fa fa-eye"></i>'.$list_views.' views</span></b><br><span class="content" id="one" style="color:rgb(140,140,140);font-family: Source Sans Pro,sans-serif 
;">
<span class="hov" style="padding:3px;border:none;font-weight:bold;">

<i class="fa fa-comment"></i>'.$num_post_query.'</span><span>

'. str_replace('h2','',str_replace('<h1>','',substr($list_content,0,120))) .'</span>
<span style="color:brown;font-weight:bold;margin-left:4px;font-size:9px;"></span>

</div>


    
</div></a>';

}


?>


</div>





<?php

include "sidebar.php";

?>




</div>


<?php

include "footer.php";

?>


<style>
    
    
    .input-container{
        
        box-shadow:0px 8px 8px 0px rgb(200,200,200);
    }
    
    
</style>



</body>

</html>