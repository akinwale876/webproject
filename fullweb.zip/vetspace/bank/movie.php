<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Nollywood Movie <?php
if(isset($_GET['page'])){
    
   echo ' Page ' . $_GET['page'];
    
}



?>- Naija Ramz Latest Nollywood Movie</title>


<?php

include  $_SERVER['DOCUMENT_ROOT'] . "/head.php";

?>


<meta name="description" content="download latest nollywood movies " />
<link rel="canonical" href="https://naijaramz.com/movie.php" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Movie - Download Latest Yoruba Movie" />
<meta property="og:description" content=" download latest yoruba movies " />
<meta property="og:url" content="http://naijaramz.com/movie" />


</head>

<body>

<?php

include $_SERVER['DOCUMENT_ROOT'] . "/header.php";

?>

<div class="wrapper">
<h2>Category: Nollywood  Movies <?php


if(isset($_GET['page'])){
    
   echo 'Page ' . $_GET['page'];
    
}



?></h2>


<div class="main" style="background:white;color:black;">
<?php


require $_SERVER['DOCUMENT_ROOT'] . '/connection.php';


$p = 0;


if(isset($_GET['page'])){
    
   $p =  $_GET['page'] * 16;
    
}



$list_post_query = mysqli_query($conn,"SELECT * FROM movies  ORDER BY id DESC LIMIT $p,16 ");


if(mysqli_num_rows($list_post_query) > 0){
    
    
    echo '<h4 style="box-shadow:0px 2px 2px 0px rgb(200,200,200);">New Post</h4>';

}




while($mov = mysqli_fetch_array($list_post_query)){

$list_title = $mov['title'];
$list_cleanurl = $mov['cleanurl'];
$list_image = $mov['picture_url'];
$list_discription = $mov['short_story'];
$list_video_id = $mov['video_id'];
$list_category = $mov['category'];
$list_date = date('l  d-M-Y',$mov['date']);





/*echo   '<a style="text-decoration:none;"  href="https://'.$_SERVER["SERVER_NAME"] .'/movie/'.$list_cleanurl.'">
<p style="font-size:14px;">Download: '.preg_replace("/[^:a-zA-Z0-9\-|]/",' ',ucfirst($list_title)) .'</p></a>';*/



echo '<a style="text-decoration:none;color:black;" href="http://'. $_SERVER["SERVER_NAME"].'/movie/'.$list_cleanurl.'">
<div class="post" style="position:relative;">


<img alt="'. preg_replace("/[^:a-zA-Z0-9\-|]/",' ',$list_title).'" class="img" src="'.str_replace('http','https',$list_image).'">


<div class="post-title">
<h4 style="margin-bottom:8px;">Download: '.preg_replace("/[^:a-zA-Z0-9\-|]/",' ',ucfirst($list_title)).'</h4>

<small style="color:rgb(190,190,190);"><em><span style="color:rgb(140,140,100);font-size:9px;"><i class="fa fa-clock">'. $list_date .'</i></span></em> <span style="color:brown;font-weight:bold;margin-left:4px;font-size:9px;"></span></small>

</div>

    
    
</div></a>';



}







$pig_query = mysqli_query($conn,"SELECT * FROM movies");



$num = mysqli_num_rows($pig_query) / 64;

$num_skip = mysqli_num_rows($pig_query) / 16;


echo '<fieldset style="padding:0;border:1px solid rgb(200,200,200);"><legend>Pages</legend><center>';

  for($i = 2;$i < $num; $i++){
      
      if($i == $_GET['page']){
          
          continue;
      }
      
          echo '<a style="display:inline-block;border-radius:10px;margin:5px;background:rgb(222,222,222);padding:5px;font-size:10px;" href="http://naijaramz.com/movie/page/'. $i.'">'.$i.'</a>';

      
  }
  
  echo '....';
  
  for($z = 36;$z < $num_skip; $z++){
      
      if($z == $_GET['page']){
          
          continue;
      }
      
          echo '<a style="display:inline-block;border-radius:10px;margin:5px;background:rgb(222,222,222);padding:5px;font-size:10px;" href="http://naijaramz.com/movie/page/'. $z.'">'.$z.'</a>';

      
  }
  
  if($p == 0){
      
    $pp =  2;
      
      
  }else{
      
      
      if($p != 16){
          
            $pp  = 1+ ($p / 16);
          
      }
  }
  
  

          echo '<a style="color:white;display:inline-block;border-radius:10px;margin:5px;background:rgb(200,40,40);padding:5px;" href="http://naijaramz.com/movie/page/'. $pp.'">Next</a>';


echo '</center></fieldset>';






?>





<h2>Category: Nollywood Movies <?php


if(isset($_GET['page'])){
    
   echo 'Page ' . $_GET['page'];
    
}



?></h2>

</div>


















<?php

include $_SERVER['DOCUMENT_ROOT'] . "/sidebar.php";

?>

</div>


<?php

include  $_SERVER['DOCUMENT_ROOT'] . "/footer.php";

?>


</body>

</html>