

<script   src="jquery.js"></script>

<link rel="stylesheet" href="mainstyle.css" />


<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700|Roboto|Lato:400,900|Source+Sans+Pro:400,700|Montserrat:800" rel="stylesheet">


<link rel="stylesheet" href="ainstylemobile.css"/>


<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=yes">


<!--.........................google adsense......................-->






<!--.........................google adsense......................-->






<link href="//db.onlinewebfonts.com/c/2cb3e62148b528138a35061500162dee?family=Nasalization" rel="stylesheet" type="text/css"/>





 <link rel="icon"  type="images/x-icon" href="https://authmain.xyz/0.png">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
