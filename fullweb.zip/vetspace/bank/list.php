
    <nav style="box-shadow: none;outline: none;" ><ul class="ul-list" id="nn">



    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/about" title="updates and latest post" style="position:relative;text-indent:10px;">About

        </a>

        </li>

    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/contact" title="updates and latest post" style="position:relative;text-indent:10px;">Contact us

        </a>

        </li>
    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/login" title="updates and latest post" style="position:relative;text-indent:10px;">Login

        </a>

        </li>

 

<style>
    
.movielist::after{

   content: "";
   border-color:white transparent  transparent  transparent ;
   border-style: solid;
   border-width: 6px;
   position: absolute;
  top:11px;
   



}




.movieshowcase{
min-width: 100px;
    display: none;
    position: absolute;bottom:-40px; 
    z-index:1;
}


#pshow:hover .movieshowcase{
min-width:208px;
    display: block;
}.movieshowcase a{

    display: block;
}


</style>


<script type="text/javascript">


  var x = 0;

function clix() {



  var nn = document.getElementById('nn');

if(x == 0){


    nn.style.height = "315px";

    x = 1;

    this.innerHTML = "&times;";
}
else{

        nn.style.height = "34px";
 x = 0;
}



}








    




</script>



<style>
    
    
    .sit::after{
        
        content:"";
        position:absolute;
        top:100%;
        left:30%;
        border-width:4px;
        border-color:rgb(200,40,40) transparent  transparent  transparent ;
        border-style:solid;
       
       
       
        
    }
    
    
    a{
        color:black;
    }
    
</style>



    </ul></nav>
    
    
    