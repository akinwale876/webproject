<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>About US - Escrow account  </title>

<?php

include "head.php";

?>


</head>


<body>

<?php

include "header.php";

?>
<div style="background-image:url('photo.jpg');background-color:#cccccc;background-position:center;background-repeat:no-repeat;background-size:cover;min-height:500px;">


<center>
    
    <h4>About</h4>


<div style="margin:5px;margin-top:20px;background:white;width:300px;min-height:360px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;display:inline-block;border-radius:0px 8px 0px 8px;overflow:hidden;">
        
        <img src="https://authmain.xyz/How-to-Open-an-Escrow-Account-for-Security-Deposit.jpg" width="100%" height="200px">

    
    <center>
        
      

<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;">Escrow account</h1>

      
      
      <p>An escrow is a process wherein the Buyer and Seller deposit written instructions, documents, and funds with a neutral third party until certain conditions are fulfilled.</p>
      
      <p>The company then transfers the ownership of the property to the Buyer through recordation and pays the Seller.</p>
      
      
      
</center>


    
</div>


<div style="margin:5px;margin-top:20px;background:white;width:300px;min-height:360px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;display:inline-block;border-radius:0px 8px 0px 8px;overflow:hidden;">
    
    <img src="https://authmain.xyz/4d74851d0e7089323978ba449ad7ad692193d263.webp" width="100%" height="200px">
    
    
    
    
    <center>
        
        

<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;">Escrow account</h1>

      
      
      <p> Being in escrow is a contractual arrangement in which a third party receives and disburses money or property for the primary transacting parties, most generally, used with plentiful terms that conduct the rightful actions that follow. The disbursement is dependent on conditions agreed to by the transacting parties</p>
      
      <p> Escrows have changed the way the world does business</p>
      
      
      
      
</center>

    
</div>



<div style="margin:5px;margin-top:20px;background:white;width:300px;min-height:360px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;display:inline-block;border-radius:0px 8px 0px 8px;overflow:hidden;">
        
        <img src="https://authmain.xyz/Escrow-Account.png" width="100%" height="200px">

    
    <center>
        
 

<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;">Escrow account</h1>

      
      
      <p>It builds trust amongst two parties involved in a transaction without involving a third party, Its taking our world to a whole new level</p>
      
      
      
</center>
    <br>


    
</div>


</center>
<p style="color:rgb(100,100,100);font-weight:400;">
    
    
   
<small style="font-size:9px;">

<script language="JavaScript">

document.write('&copy;' );
document.write(' <b><i>Online Escrow</i> ');
document.write(new Date().getFullYear());
document.write(' </b> Alright Reserved');

</script>

</small>
 
</p>
</div>


</body>

</html>