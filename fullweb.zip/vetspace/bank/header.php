<div class="header">
<div style="padding-top:18px;"></div>

<?php

include "admin_init.php";

?>


<div class="left-header" style="position:relative;">
    
    
    

<a href="https://<?php echo $_SERVER['SERVER_NAME']?>">
    
    
    <div class="header-image" style="display:inline-block;">  

</div>
<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;">Online escrow account</h1>
</a>  


</div>


<span  style="margin-right:20px;float:right;">
    

<?php

include "list.php";

?>

</span>


<br>
<br>


    </div>
    
    
