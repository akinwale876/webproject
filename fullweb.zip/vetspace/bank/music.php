<!DOCtype html>

<html>

  <head>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

      <title>Music - Naija Ramz </title>

        <?php

            include "head.php";

         ?>

<meta name="description" content="visit us today and dowload hot naija music " />

        <link rel="canonical" href="https://naijaramz.com/Music" />

         <meta property="og:locale" content="en_US" />

         <meta property="og:type" content="object" />

         <meta property="og:title" content="Music &raquo; Naija Ramz" />

         <meta property="og:description" content="hot naija music world" />

         <meta property="og:url" content="http://naijaramz.com/Music" />

         <meta property="og:site_name" content="Naija Ramz" />

</head>

<body>

    <?php

            include "header.php";

           ?>

    <div class="wrapper">

                <h2>Category: Music</h2>

            <div id="player" style="position:fixed;bottom:5px;right:0;z-index:1;">
    

           </div>



         <script>
    
    
           function play(srcUrl){
               
        
        var au = document.getElementById('player');
        
au.innerHTML = '<audio class="audio" controls="controls" autoplay><source id="getAudio" type="audio/mpeg" src="' + srcUrl +'"></audio>';
        
        
        this.innerHTML = 'pause';
        
         }
    
    
    
         </script>


                <div class="main">
    
                              <?php


                       require 'connection.php';
                       
                    
$p = 0;


if(isset($_GET['page'])){
    
   $p =  $_GET['page'] * 16;
    
}



$list_post_query = mysqli_query($conn,"SELECT * FROM music  ORDER BY id DESC LIMIT $p,16 ");
   
                       
                      

                                   if(mysqli_num_rows($list_post_query) > 0){
                                   echo '<h5 style="background-color:white;color:black;padding: 8px;box-shadow: 0px 2px 6px rgb(100,100,100);">Hot Musics</h5>';
                                       
                                   }


//fetching post data.....from db

                       while($mov = mysqli_fetch_array($list_post_query)){

$list_title = $mov['title'];

$list_cleanurl = $mov['cleanurl'];

$list_image = $mov['picture_url'];

$list_url = $mov['music_url'];

$list_discription = $mov['description'];
$list_category = $mov['category'];
$list_views = $mov['views'];
$list_date = date('d-M-Y',$mov['date']);

$likes = $mov['likes'];

$er = str_replace('http','https',$list_url);

$mus = "play('".$er."')";

echo '<a style="text-decoration:none;color:black;" href="http://'.$_SERVER["SERVER_NAME"].'/music/'.$list_cleanurl.'">

<div class="post" style="position:relative;">

<img alt="'. preg_replace("/[^:a-zA-Z0-9\-|]/",' ',$list_title).'" class="img" src="'.str_replace('http','https',$list_image).'">

<div class="post-title" style="position:relative;">
<h4 style="margin-bottom:8px;">'. ucfirst($list_title).'</h4>
<span style="color:rgb(140,140,100);font-size:10px;">'. substr($list_discription,0,190).'</span></small>
<br></a>

<br>

</div>


    
    <button style="position:absolute;bottom:0;right:0;font-size:10px;outline:none;border:none;cursor:pointer;" onclick="'.$mus.'">Play</button>
    <button style="position:absolute;bottom:0;left:0;font-size:10px;outline:none;border:none;cursor:pointer;">views : '.$list_views.'</button>

</div>';

}






$pig_query = mysqli_query($conn,"SELECT * FROM music");



$num = mysqli_num_rows($pig_query) / 64;

$num_skip = mysqli_num_rows($pig_query) / 16;


echo '<fieldset style="padding:0;border:1px solid rgb(200,200,200);"><legend>Pages</legend><center>';

  for($i = 2;$i < $num; $i++){
      
      if($i == $_GET['page']){
          
          continue;
      }
      
          echo '<a style="display:inline-block;border-radius:10px;margin:5px;background:rgb(222,222,222);padding:5px;font-size:10px;" href="https://naijaramz.com/music/page/'. $i.'">'.$i.'</a>';

      
  }
  
  echo '....';
  
  for($z = 36;$z < $num_skip; $z++){
      
      if($z == $_GET['page']){
          
          continue;
      }
      
          echo '<a style="display:inline-block;border-radius:10px;margin:5px;background:rgb(222,222,222);padding:5px;font-size:10px;" href="http://naijaramz.com/music/page/'. $z.'">'.$z.'</a>';

      
  }
  
  if($p == 0){
      
    $pp =  2;
      
      
  }else{
      
      
      if($p != 16){
          
            $pp  = 1+ ($p / 16);
          
      }
  }
  
  

          echo '<a style="color:white;display:inline-block;border-radius:10px;margin:5px;background:rgb(200,40,40);padding:5px;" href="http://naijaramz.com/music/page/'. $pp.'">Next</a>';


echo '</center></fieldset>';








?>

</div>


<?php

include "sidebar.php";

?>

</div>


<?php

include "footer.php";

?>


</body>



        <style>
    
          .post{
        
        display:inline-block;
        }
    
    
        </style>

</html>