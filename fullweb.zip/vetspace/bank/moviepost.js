
var title,description,category,tag,videoid,content,data;

// preparing variables 

function _(el){

return document.getElementById(el);


}




// ..beginning of form validation...
function uploadMovie(){




title = _('title');
description =_('description');
videoid =_('videoid');
file = _('file').files[0];

 category = _('category');
 tag = _('tag');
 content = _('content');


var formdata = new FormData();

formdata.append('title', title.value);
formdata.append('description', description.value);
formdata.append('video_id', videoid.value);
formdata.append('category', category.value);
formdata.append('tag', tag.value);
formdata.append('content', content.value);
formdata.append('file', file);


if (window.XMLHttpRequest) {
    // code for modern browsers
   var aja = new XMLHttpRequest();
 } else {
    // code for old IE browsers
   var aja = new ActiveXObject("Microsoft.XMLHTTP");
}


aja.upload.addEventListener('progress', progressHandle, false);
aja.addEventListener('load', completeHandle, false);
aja.addEventListener('error', errorHandle, false);
aja.addEventListener('abort', abortHandle, false);
aja.open("POST", "moviepost_server.php");
aja.send(formdata);




}


function progressHandle(event){

    _('loaded').innerHTML = "uploaded " + event.loaded + "bytes of " + event.total;

var percent = (event.loaded / event.total) * 100;

_('progressbar').value = Math.round(percent);
_('status').innerHTML = Math.round(percent) + "% upload... please wait";


}

function completeHandle(event){

_('status').innerHTML = event.target.responseText;

_('progressbar').value = 0;

}

function errorHandle(event){

_('status').innerHTML = "upload failed";



}

function abortHandle(event){

_('status').innerHTML = "upload aborted";



}

