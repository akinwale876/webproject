

<br>



<?php


$comment_sql = "SELECT * FROM comment WHERE comment_id='$comment_id'";

$comment_query = mysqli_query($conn,$comment_sql);

if(mysqli_num_rows($comment_query) > 0){
    
    echo '<h2 name="comment">Comments('.mysqli_num_rows($comment_query).')</h2>';

    
}else{
    echo '<h2 style="text-align:center;" name="comment"> No Comment Yet</h2>';

}



while($comment_data = mysqli_fetch_array($comment_query)){
    
    
$comment_name = $comment_data['name'];

$comment_email = $comment_data['email'];

$comment_comment = $comment_data['comment'];

$comment_date =  date(' l m:ha d-M-Y',$comment_data['date']);




     
echo '  <div class="data">

              <div class="left-side">
<img style="border:none;border-radius:50%;" src="https://naijaramz.com/icons/images.png" height="60px" width="60px">
              </div>
              <div class="right-side">
              
              <h4>'.$comment_name.' Says   "<i style="color:green;">'.$comment_comment.'</i>" </h4> 

<small><span style="color:rgb(220,20,20);"><b style="color:rgb(220,20,20);"><i class="fas fa-clock"> '.$comment_date.'</i></b></span></small>
<br>


              </div>

       </div>  ';
            

    
}








?>




<br>


<h2><img src="https://naijaramz.com/icons/chat.png" height="20px">Leave a Comment</h2>





<form id="commentForm" action="" method="post" onsubmit="return false">
    
         <div class="input-container" style="width:90%;">
             
                                <input type="hidden"  id="commentId" value="<?php echo $comment_id;?>" />

             
             
             <?php
             
             if(isset($_COOKIE['commentname'])){
                 
                 $comment_name = $_COOKIE['commentname'];
                 
                 echo '<h5>Welcome <span style="color:gold;" >'. $comment_name .'</span> add your comment</h5>
                 <input type="hidden" id="name" value="'. $comment_name.'" />';
             }else{
                 
                 echo '<input type="text" name="name" id="name" placeholder="Name" />
                   <input type="checkbox" value="name" id="check"  /><label style="font-size:9px;" for="check">Save your info</label>
                   ';
             }
             
             ?>
                   
                   
                   
                   
         </div>
         
         <div class="input-container" style="width:90%;">
             
             
                  <?php
             
             if(isset($_COOKIE['commentemail'])){
                 
                 $comment_email = $_COOKIE['commentemail'];
                 
                 echo '<p>Your Email: <span style="color:rgb(100,100,100);" >'. $comment_email .'</span></p>
                 <input type="hidden" id="email" value="'. $comment_email.'" ><label><span style="color:red;">Note: </span>Only you can see this</label>';
             }else{
                 
                 echo '<input type="text" name="email"  id="email" placeholder="Email" />

                   ';
             }
             
             ?>
               
             </div>
             
         
         <br>     <center>
             
           <textarea id="comment" rows="7" style="width:90%;"  name="comment" placeholder="Place Comment"></textarea>
         </center>
         
         
        
    
      
         <br>
         
        
         <div class="input-container" style="width:90%;">
 <input style="font-size:11px;border-radius:10%;padding:8px;border:1px solid rgb(20,20,20);color:rgb(20,20,20);" type="submit" name="submit" id="submit" onclick="comm()" value="Add Comment!" />
         </div>
         
         
         <br>
         <br>
         <br>
</form>




<script>
    
    
    $('#submit').click(function(){
        
        if($('#check').is(":checked")){
            
                    var check = $('#check').val();

        }
        
        
        var name = $('#name').val();
        var email = $('#email').val();
        var comment = $('#comment').val();
        var website = $('#website').val();
        var commentId = $('#commentId').val();

        
        
        $.post("https://naijaramz.com/comment_server.php", {
    check: check,
     name: name,
    email: email,
    comment: comment, 
    website: website,
    comment_id: commentId
  }
  
  ,function(data){
        
        
        alert(data);
        
        
        
     
        
    });
    
    
    
    
    })
</script>


   
         
         <br>
         
         
         
         
         
         <style>
         
                    
             
         </style>
         
         
         
         
         
         
         <br>
         <br>