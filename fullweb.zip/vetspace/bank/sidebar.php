<div class="sidebar">
	<script type="text/javascript" src="https://naijaramz.com/jquery.js"></script>

</div
