<?php

require_once __DIR__ . '/api/Facebook/autoload.php'; // change path as needed






$fb = new Facebook\Facebook([
 'app_id' => 'xxxxxxxxxx',
 'app_secret' => 'xxxxxxxxxx',
 'default_graph_version' => 'v2.2',
]);



// error variable declare herre

$errors  = array();




// check to see link

if(isset($_GET['link'])){
    
  
$link = $_GET['link'];   
    
}else{
    
    array_push($errors,'link not isset');

}



    // check to see title
if(isset($_GET['title'])){
    
$title = $_GET['title']; 
    
    
}else{
    
    
    array_push($errors,'title not isset');
    
}


    // check to see link

if(isset($_GET['pic_url'])){
    
   
$pic_url = $_GET['pic_url']; 
    
}else{
    
    
    array_push($errors,'Pic url not isset');
    
    
}

    // check to see link

if(isset($_GET['description'])){
    
    
$description = $_GET['description'];    
    
}else{
    
    
    array_push($errors,'Desc not isset');
    
    
}




if(empty($errors)){
    
    
    echo 'Title :,'.$title . 'Description :,' .$description. 'Pic url :,'.$pic_url.  'Link :' . $link;
}else{
    
    
    echo 'error detected';
}







?>

