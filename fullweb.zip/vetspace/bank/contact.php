<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Contact Us - Online escrow account </title>
<meta name="discription"
content="Contact - NaijaRamz" />

<?php

include "head.php";

?>


</head>


<body>

<?php

include "header.php";

?>




<div style="background-image: url('photo.jpg');background-color: #cccccc;background-position: center; background-repeat: no-repeat; 
  background-size: cover;min-height:500px;">



<center>
    
    
<div style="margin:5px;margin-top:40px;background:white;width:500px;min-height:360px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;display:inline-block;border-radius:0px 8px 0px 8px;overflow:hidden;">
    
    
    

<h1>Contact Us</h1>

	<form action="contact_server.php"   method="post">

    
    <div class="input-container">
    	



<input type="text" id="name" name="name" placeholder="Your Name"/>

    </div>

    
    <div class="input-container">
    	

<input type="text" id="email" name="email" placeholder="Email"/>



    </div>

		<br>
    
    	

<textarea id="message" name="message" placeholder="Message......" style="width:90%;min-height: 190px;">
</textarea>
    


		<br>
    
    
    <div class="input-container">
    	


<input type="submit" onclick="sendM()"  value="Send..!">


    </div>



	


	</form>

<div id="xdd"></div>

<script>



var name = document.getElementById('name');



var email = document.getElementById('email');



var message = document.getElementById('message');



var xdd = document.getElementById('x');



   function sendM() {
  


xdd.innerHTML ="ss...";

var formdata = new FormData();


formdata.append('name',name.value);

formdata.append('email',email.value);

formdata.append('message',message.value);



if (window.XMLHttpRequest) {
    // code for modern browsers
   var aja = new XMLHttpRequest();
 } else {
    // code for old IE browsers
   var aja = new ActiveXObject("Microsoft.XMLHTTP");
}




aja.upload.addEventListener('progress', progressHandl, false);
aja.addEventListener('load', completeHandl, false);
aja.addEventListener('error', errorHandl, false);
aja.addEventListener('abort', abortHandl, false);
aja.open("POST", "contact_server.php");
aja.send(formdata);



   	}




function progressHandl(event){

   // _('loaded').innerHTML = "uploaded " + event.loaded + "bytes of " + event.total;

//var percent = (event.loaded / event.total) * 100;

//_('status').innerHTML = Math.round(percent) + "% upload... please wait";
x.innerHTML = event.target.responseText;


}

function completeHandl(event){

x.innerHTML = event.target.responseText;


}

function errorHandl(event){

x.innerHTML = "upload failed";



}

function abortHandle(event){

x.innerHTML = "upload aborted";



}
	








</script>




    
</div>



</center>

</div>






<?php

include "footer.php";

?>


</body>
</html>