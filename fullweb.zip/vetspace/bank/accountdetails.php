
           <?php 
           if($active == 1) {echo '<div style="">

<div class="input-container">
    
    <div class="icon-left" >
    <i class="fa fa-user" id="icon"></i>
    </div>
    
    <div class="icon-right">
    <b>Account Number</b><br><br><span class="text-icon">'. $account_number . '</span>

    </div>
    
    

    

</div>

<div class="input-container">
    <div class="icon-left">
   <i class="fas fa-money-check" id="icon"></i> 
    </div>
    
    <div class="icon-right" >
    <b>Account Type</b><br><br><span class="text-icon" style="">'.$account_type .'</span>

    </div>
    
    
</div>

<div class="input-container">
    
    <div class="" style="position:absolute;right:30px;top:20px;">
    <b>Account Balance</b><br><br><span class="text-icon">'.  $currency .  number_format($balance) . '</span>

    </div>
    
    
</div>

<div class="input-container">
    <div class="icon-left" >
   <i class="fas fa-money-bill" id="icon"></i> 
    </div>
    
    <div class="icon-right" >
    <b>Account Currency</b><br><br><span class="text-icon">'. $currency . '</span>

    </div>
    
    
</div>

</div>';
}
else{
    
    
          echo '<h4 style="color:red;">your account is not activated yet<a href="https://authmain.xyz/sendcode.php"> activate your account to unable you to post</a></h4>';

    
}


?>

