
    

<?php


if(!isset($_COOKIE['cat'])) {


$cookie_name = "cat";
$cookie_value = $category;
    
    setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");

    
} else {
    
}


?>
