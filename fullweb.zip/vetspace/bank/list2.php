

    <nav><ul class="ul-list" style="background:none;">

    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/about" >About Us</a>

        </li>
    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/contact" >Contact Us</a>

        </li>
   
    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/privacy-policy" >Privacy Policy</a>

        </li>     
        
        
 
  
        

<script>



       $('#upp').click(function(){
           
           
                   $('html,body').animate({scrollTop:0},600);

           
       })

  




</script>
<script>




        

    </script>



    </ul>
    
    <style>
        
        ul.ul-list li a{
            
            text-decoration:none;
            


        }
        
       .footer ul.ul-list li a{
            font-size:12px;

        }
        
        
    </style>
    
    
    </nav>